import React from "react";

const ZeroFourZero = () => {
    return(
        <h1 className="box-title text-danger">Error 404.</h1>
    )
}
export default ZeroFourZero;